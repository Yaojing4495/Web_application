import React from 'react';
import {
  Grid,
  Typography,
  Card,
  Box,
  IconButton,
  CardMedia,
  DialogContent,
  Dialog,
  DialogTitle
} from '@material-ui/core';
import {
    DeleteOutline
  } from "@material-ui/icons";

import './Favorites.css';
// import { Link } from "react-router-dom";
import axios from 'axios';


/**
 * Define Favorites
 */
class Favorites extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      //users: undefined,
      modalWindow: [],
      favorites: []
    };
    this.DeleteFavoritePhotos = this.DeleteFavoritePhotos.bind(this);
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/getFavoritePhoto`)
      .then(response => {
        let inn_modalWindow = [];
        for (let i = 0; i < response.data.length; i++) {
          inn_modalWindow.push(false);
        }
        this.setState({
          favorites: response.data,
          modalWindow:inn_modalWindow
        });
      }).catch(() => this.setState({favorites:[]}));
  }
  
  DeleteFavoritePhotos = (photo) => {
    axios.get(`/deleteFavoritePhoto/${photo._id}`)
    .then(() => {
        axios.get(`/getFavoritePhoto`)
        .then((response)=> {
        this.setState({favorites: response.data});
        }).catch(err => console.log(err.response));
    }).catch(err => console.log(err.response));
  };

  closeModalWindow = (index) => {
    let new_modalWindow = JSON.parse(JSON.stringify(this.state.modalWindow));
    new_modalWindow[index] = false;
    this.setState({modalWindow: new_modalWindow});
  };

  openModalWindow = (index) => {
    let new_modalWindow = JSON.parse(JSON.stringify(this.state.modalWindow));
    new_modalWindow[index] = true;
    this.setState({modalWindow: new_modalWindow});
   };

  render() {
    return (
        <Grid container justify="flex-start" alignItems="flex-start">
            <Grid item xs={12}>
                <Typography variant="h4">Favorite photos</Typography>
            </Grid>
            {this.state.favorites.map((photo,index) => ( 
              <Box key={photo._id} margin={3} className="favorite-photo-box">
                <Card>
                  <IconButton size="small" onClick={() => this.DeleteFavoritePhotos(photo)}>
                    <DeleteOutline />
                  </IconButton>
                  <CardMedia className="favorite-photo-thumbnail"
                    component="img"
                    image={`/images/${photo.file_name}`}
                    onClick={()=>this.openModalWindow(index)} />
                </Card>
                <Dialog className="favorite-photo-dialog"
                    open={this.state.modalWindow[index]}
                    onClose={()=>this.closeModalWindow(index)}
                  >
                    <DialogTitle>
                      {`created on ${photo.date_time}`}
                    </DialogTitle>
                    <DialogContent>
                      <img src={`/images/${photo.file_name}`} className="favorite-photo-large" />
                    </DialogContent>
                </Dialog>
              </Box>

            ))}
        </Grid>
    );
  }
}

export default Favorites;
