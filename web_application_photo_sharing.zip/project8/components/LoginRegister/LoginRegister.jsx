import React from "react";
import { 
  Grid, 
  Typography, 
  TextField,
  Button} from "@material-ui/core";
import axios from 'axios';
import './LoginRegister.css';

class LoginRegister extends React.Component {
  constructor(props) {
    super(props);
    this.handleLogin = this.handleLogin.bind(this);
    this.handleinput = this.handleinput.bind(this);
    this.handleRegister = this.handleRegister.bind(this);
    this.state = {
      login_username_input: "",
      login_password_input: "",
      register_name_input: "",
      register_password_input: "",
      register_password_2_input: "",
      register_location_input: "",
      register_occupation_input: "",
      register_description_input: "",
      register_first_name_input: "",
      register_last_name_input: "",
      registerError: "",
      loginError: "",
    };
  }

  handleinput = (stateUpdate)=> {
    this.setState(stateUpdate);
  };

  handleLogin = (event) => {
    event.preventDefault();
    let user = localStorage.getItem('user');
    user = JSON.parse(user);
    console.log(user);
    let passwords = localStorage.getItem('passwords');
    passwords = JSON.parse(passwords);
    if (user && passwords) {
      let promise = axios.post("admin/login", {
        login_name: user.login_name,
        password: passwords
      });
      promise.then(response => {
        this.setState({loginError: ""});
        let this_user = response.data;
        console.log(this_user);
        this.props.changeLogin(this_user);
        window.location.href = `#/users/${this_user._id}`;
        console.log(this_user);
      }).catch(err => {
        this.handleinput({loginError: err.response.data});
      }); 
    } else {
      let promise = axios.post("admin/login", {
        login_name: this.state.login_username_input,
        password: this.state.login_password_input
      });
      promise.then(response => {
        this.setState({loginError: ""});
        let this_user = response.data;
        this.props.changeLogin(this_user);
        console.log(this_user);
        window.location.href = `#/users/${this_user._id}`;
        localStorage.setItem('user', JSON.stringify(response.data));
        localStorage.setItem('passwords', JSON.stringify(this.state.login_password_input));
      }).catch(err => {
        this.handleinput({loginError: err.response.data});
      }); 
    } 
  };


  handleRegister = (event)=> {
    event.preventDefault();
    if (this.state.register_password_input !== this.state.register_password_2_input) {
      this.setState({registerError: "Passwords don't match"});
      return;
    }
    axios.post("/user", {
        login_name: this.state.register_name_input,
        password: this.state.register_password_input,
        occupation: this.state.register_occupation_input,
        location: this.state.register_location_input,
        description: this.state.register_description_input,
        first_name: this.state.register_first_name_input,
        last_name: this.state.register_last_name_input
      }).then(response => {
        this.setState({registerError: "" });
        let this_user = response.data;
        this.props.changeLogin(this_user);
        window.location.href = `#/users/${this_user._id}`;
      }).catch(err => {
        this.handleinput({registerError: err.response.data});
      });
  };

  render() {
    return (
      <Grid container justify="space-evenly">
        <Grid item sm={12}>
          <Grid item sm={12} align='center'>
            <Typography variant="h4">Log In</Typography>
          </Grid>
          <Grid item sm={12} align='center'>
            <Typography variant="body2" color="error">
                {this.state.loginError}
            </Typography>
          </Grid>
            <form onSubmit={this.handleLogin} className="log-in-form">
            <Grid item sm={12} align='center' >
              <TextField id="session_username" className="login-text" label = "Username" required placeholder='Enter Username' 
              value={this.state.login_name_input} onChange={event => this.handleinput({login_username_input: event.target.value})}/>
            </Grid>
              <Grid item sm={12} align='center' >
              <TextField id="session_password" className="login-text" type='password' label = "Password" required
                placeholder='Enter Password' value={this.state.login_password_input}
                onChange={event =>this.handleinput({login_password_input: event.target.value})}/>
              </Grid>
              <Grid item className="btn" sm={12} align='center' >
                <Button type = 'submit' color='primary'>Log in</Button>
              </Grid>
              <Grid item sm={12} align='center'>
                <Typography variant="body1" color="secondary">New User? Fill out the form below to register</Typography>
              </Grid>
            </form>
        </Grid>

        <Grid item sm={12}>
          <Grid item sm={12} align='center'>
            <Typography variant="h4">Register</Typography>
          </Grid>
          <Grid item sm={12} align='center'>
            <Typography variant="body2" color="error">
              {this.state.registerError}
            </Typography>
          </Grid>

          <form onSubmit={this.handleRegister} className="register-form">
          <Grid item sm={12} align='center' >
            <TextField className="register-text" label = "Username" required
            placeholder='Enter Username' value={this.state.register_name_input}
            onChange={event =>this.handleinput({register_name_input: event.target.value})}/>
          </Grid> 
          <Grid item sm={12} align='center' >
              <TextField className="register-text" type='password' label = "Password" required
              placeholder='Enter Password' value={this.state.register_password_input}
              onChange={event =>this.handleinput({register_password_input: event.target.value})}/>
          </Grid>
          <Grid item sm={12} align='center' >
              <TextField className="register-text" type='password' label = "Confirm Password" required
              placeholder='Enter Password' value={this.state.register_password_2_input}
              onChange={event =>this.handleinput({register_password_2_input: event.target.value})}/>
          </Grid>
          <Grid item sm={12} align='center' >
              <TextField className="register-text" label = "First Name" required
              placeholder='Enter first name' value={this.state.register_first_name_input}
              onChange={event =>this.handleinput({register_first_name_input: event.target.value})}/>
          </Grid>
          <Grid item sm={12} align='center' >
              <TextField className="register-text" label = "Last name" required
              placeholder='Enter last name' value={this.state.register_last_name_input}
              onChange={event =>this.handleinput({register_last_name_input: event.target.value})}/>
          </Grid>
          <Grid item sm={12} align='center' >
              <TextField className="register-text" label = "Occupation" 
              placeholder='Enter Occupation' value={this.state.register_occupation_input}
              onChange={event =>this.handleinput({register_occupation_input: event.target.value})}/>
          </Grid>
          <Grid item sm={12} align='center' >
              <TextField className="register-text" label = "Location" 
              placeholder='Enter Location' value={this.state.register_location_input}
              onChange={event =>this.handleinput({register_location_input: event.target.value})}/>
          </Grid>
          <Grid item sm={12} align='center' >
              <TextField className="register-text" label = "Description" 
              placeholder='Enter Description' value={this.state.register_description_input}
              onChange={event =>this.handleinput({register_description_input: event.target.value})}/>
          </Grid>
          <Grid className="btn" item sm={12} align='center' >
            <Button type = 'submit' color='primary'>Register Me</Button>
          </Grid>
          </form>
        </Grid>
      </Grid>
    );
  }
}

export default LoginRegister;

