import React from 'react';
import {
  Typography,
  Grid,
  Button,
  Card,
  CardMedia,
  CardContent,
  Divider,
  Box,
  MobileStepper
} from '@material-ui/core';
import './UserPhotosNew.css';
import { Link } from "react-router-dom";
import axios from 'axios';

/**
 * Define UserPhotos, a React componment of CS142 project #5
 */
class UserPhotosNew extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      photos:undefined,
      user:undefined,
      activeStep:0,
      maxStep:undefined,
      //comment:""
      //feature:this.props.feature
    };
    this.handleNext = this.handleNext.bind(this);
    this.handleBack = this.handleBack.bind(this);
    this.addNewComment = this.addNewComment.bind(this);
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/photosOfUser/${this.props.match.params.userId}`)
    .then(response => {
      if(this._isMounted) {
        this.setState({
          photos: response.data,
          maxStep: response.data.length
        });}
    }).catch((err)=> {
      console.error(err);
    });

    axios.get(`/user/${this.props.match.params.userId}`)
    .then(response => {
      if(this._isMounted) {this.setState({user: response.data});
      this.props.changeTitle(`Photos of: ${response.data.first_name} ${response.data.last_name}`);}
    }).catch((err)=> {
      console.error(err);
    });
  }

  handleNext = () => {
    this.setState({activeStep:this.state.activeStep+1});
  };
  handleBack = () => {
    this.setState({activeStep:this.state.activeStep-1});
  };

  addNewComment=(photoId, userId)=>{
    let input_comment = document.getElementById(photoId);
    const promise = axios.post(`/commentsOfPhoto/${photoId}`, {comment: input_comment.value});
    input_comment.value = "";
    promise.then(() => {
        axios.get(`/photosOfUser/${userId}`)
        .then((response)=>{
          this.setState({photos: response.data});
        }).catch((err) => {
          console.error(err);
        });
    }).catch((err)=> {
      console.error(err);
    });
  };

  render() {
    return this.state.user? (
      <Grid container 
        direction="column" 
        alignItems="flex-start">
          <Grid item>
            <Typography variant="h5">
              {`Welcome to ${this.state.user.first_name} ${this.state.user.last_name}'s photo page!`}
            </Typography>
            <Typography variant="body2">New feature enabled</Typography>
          </Grid>
          
          <Grid item className="user-photo-back">
            <Button variant="outlined" size = "small">
              <Link to={`/users/${this.state.user._id}`} key={this.state.user._id}>
                {`Back to ${this.state.user.first_name} ${this.state.user.last_name}'s homepage`}
              </Link>
            </Button>
          </Grid>

        {/* show photos */}
        <Box sx={{ maxWidth: 400, flexGrow: 1 }}>
          {this.state.photos ? (
            <Box className = "new-photo-feature" margin = {3} height={600}>
              <Card>
                <CardMedia 
                  component="img"
                  image = {`/images/${this.state.photos[this.state.activeStep].file_name}`}
                  height = {400}>
                </CardMedia>

                <CardContent>
                  <Typography gutterBottom className="user-photo-time" variant="body2">
                      {`${this.state.photos[this.state.activeStep].date_time}`}
                  </Typography>
                  <Typography className="user-photo-comment-title" variant="body1">Comments:</Typography>
                  {this.state.photos[this.state.activeStep].comments ? this.state.photos[this.state.activeStep].comments.map(comment => 
                    {return (
                      <Box key={comment._id} margin={2} className='user-photo-comment-box'>
                        <Divider />
                        <Grid className="user-photo-comment-creater">
                          {`${comment.date_time} from : `}
                          <Link to={`/users/${comment.user._id}`}>
                              {`${comment.user.first_name} ${comment.user.last_name}`}
                          </Link>
                        </Grid>
                        <Grid item className="user-photo-comment-content">
                          {comment.comment}
                        </Grid>
                      </Box>
                  );}
                  ) : (
                    <Box margin={3}>
                      No comments yet...
                    </Box>
                  )}
                </CardContent>
                <form onSubmit = {() => this.addNewComment(this.state.photos[this.state.activeStep]._id, this.state.photos[this.state.activeStep].user_id)}>
                        {'Add a comment:  '}
                        <input type = "text" id={`${this.state.photos[this.state.activeStep]._id}`}></input>
                        <Button type="submit" color="primary">send</Button>
                </form>
              </Card>
            </Box>
            ) : (
              <div>loading...</div>
            )}


        </Box>      
        
        <MobileStepper
          className = "mobile-stepper"
          variant="text"
          steps={this.state.maxStep}
          position="static"
          activeStep={this.state.activeStep}
          nextButton={
            (
            <Button
              size="small"
              onClick={this.handleNext}
              disabled={this.state.activeStep === this.state.maxStep - 1}
            >
              Next
            </Button>
            )
          }
          backButton={
            (
            <Button size="small" onClick={this.handleBack} disabled={this.state.activeStep === 0}>
              Back
            </Button>
            )
          }
        />

      </Grid>
    ) : (
    <div>loading...</div>
    );
  }
}

export default UserPhotosNew;
