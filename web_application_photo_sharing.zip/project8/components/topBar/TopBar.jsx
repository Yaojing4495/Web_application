import React from 'react';
import {
  AppBar, Toolbar, Typography,Grid,
  Button, Dialog, DialogTitle, 
  DialogActions
} from '@material-ui/core';
import './TopBar.css';
import { Link } from "react-router-dom";
import axios from 'axios';
/**
 * Define TopBar, a React componment of CS142 project #5
 */
class TopBar extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      version: undefined,
      title: this.props.title,
      //this_user: this.props.this_user,
      dialogOpen: false
      //feature:this.props.feature
    };
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/test/info`)
    .then(response => {
      if(this._isMounted) {
        this.setState({
          version: response.data.__v,
        });
      }
    }).catch((err)=> {
      console.error(err);
    });
  }

  handleLogout = () => {
      this.props.changeLogin(undefined);
      localStorage.clear();
  };


  handleUploadButtonClicked = (e) => {
    e.preventDefault();
    if (this.uploadInput.files.length > 0) {
     const domForm = new FormData();
     domForm.append('uploadedphoto', this.uploadInput.files[0]);
     axios.post('/photos/new', domForm)
       .then((res) => {
         console.log(res);
         window.location.href = `#/photos/${this.props.this_user._id}`;
         window.location.reload();
       })
       .catch(err => console.log(`POST ERR: ${err}`));
    }
  };
  
  componentDidUpdate = (prevProps) => {
    if (prevProps.title !== this.props.title) {
      this.setState({title: this.props.title});
    }
  };

  setEnabled = () => {
    this.props.changeFeature(!this.props.feature);
    console.log(this.props.feature);
  };

  handleDialogOpen = () => {
    this.setState({dialogOpen: true});
  };
  handleDialogClose = () => {
    this.setState({dialogOpen: false});
  };
  render() {
    return (
      <AppBar className="cs142-topbar-appBar" position="absolute">
        <Toolbar>
        {this.props.this_user ? (
        <Grid container direction="row" >
          <Grid item xs={2}>
            <Typography variant="h5">
                {`Hi ${this.props.this_user.first_name}`}
            </Typography>
            <Typography variant="caption">
                  {`version: ${this.state.version}`}
            </Typography>
          </Grid >
          {/* <Grid item xs={2}>
          <FormControlLabel
          sx={{
            display: 'block',
          }}
          control={
            <Switch checked={this.props.feature} onChange={this.setEnabled} name="enabling" color="default"/>
          }
          label={`Advanced: ${this.props.feature}`}
          />
          </Grid> */}

          <Grid item xs={5}>
            <Typography variant="body1">{`${this.state.title}`}</Typography>
          </Grid>

          <Grid item xs={2}>
            <Button variant="contained" color="primary" size = "small">
              <Link color="primary" to={`/favorites`}>Favorite Photo</Link>
            </Button>
          </Grid>

          <Grid item xs={2}>
            <Button variant="contained" color="primary" size = "small" onClick={this.handleDialogOpen}>Upload photo</Button>
          </Grid>

          <Dialog className = "upload-dialog"
            open={this.state.dialogOpen}
            onClose={this.handleDialogClose}
          >
            <DialogTitle>
              {"Upload a photo"}
            </DialogTitle>
                <form onSubmit={this.handleUploadButtonClicked}>
                    <input type="file" accept="image/*" ref={newfile => {this.uploadInput = newfile;}}/>
                  <DialogActions>
                    <Button type="submit" value="Upload" onClick={this.handleDialogClose}>Upload</Button>
                    <Button onClick={this.handleDialogClose}>
                      Cancel
                    </Button>
                  </DialogActions>
                </form>
          </Dialog>


          <Grid item xs={1}>
            <Button onClick={this.handleLogout} variant="outlined" size = "small">Log out</Button>
          </Grid>
        </Grid>
        ) : 
        (
          <Typography variant="h5">Please login</Typography>
        ) }
        </Toolbar>
        
      </AppBar>
    );
  }
}

export default TopBar;
