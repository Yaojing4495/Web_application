import React from 'react';
import {
  Typography,
  CardMedia,
  Card,
  Box
} from '@material-ui/core';
import './userDetail.css';
import { Link } from "react-router-dom";
import axios from 'axios';
import { HashLink } from 'react-router-hash-link';

class MentionPhotoCard extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      this_photo:{}
    };    
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/singlePhoto/${this.props.photoId}`)
    .then(response => {
      if(this._isMounted) {this.setState({this_photo: response.data});
      }
    }).catch((err)=> {
      console.error(err);
    });
  }

  componentWillUnmount() {
    this._isMounted = false;
  }

  render() {
    return this.state.this_photo ? (
        <Box key={`box${this.state.this_photo._id}`} className="user-detail-most-comments">
        <HashLink to={`/photos/${this.state.this_photo.photo_creater_id}#photo${this.state.this_photo._id}`}>
          <Card className="user-detail-photo">
            {/* <CardMedia
              component="img"
              image={`/images/${this.state.this_photo.file_name}`} /> */}
              {this.state.this_photo.file_name?
                <CardMedia component="img" image={`/images/${this.state.this_photo.file_name}`}/>
                : null
                }
          </Card>
        </HashLink>
        <Link to={`/users/${this.state.this_photo.photo_creater_id}`}>
            <Typography variant="body2">
            {`Photo Owner: ${this.state.this_photo.creater_first_name} ${this.state.this_photo.creater_last_name}`}
            </Typography>
        </Link>
        </Box>
    ) : null;
  }
}

export default MentionPhotoCard;