import React from 'react';
import {
  Typography,
  Grid,
  Button,
  CardMedia,
  Card,
  Divider,
  Box
} from '@material-ui/core';
import './userDetail.css';
import { Link } from "react-router-dom";
import axios from 'axios';
import { HashLink } from 'react-router-hash-link';
import MentionPhotoCard from "./MentionPhotoCard";

/**
 * Define UserDetail, a React componment of CS142 project #5
 */
class UserDetail extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      user: undefined,
      most_comment:[],
      most_recent:{file_name:"",comments:[],date_time:"",id:""},
    };    
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/user/${this.props.match.params.userId}`)
    .then(response => {
      if(this._isMounted) {this.setState({user: response.data});
      this.props.changeTitle(`Photos of: ${response.data.first_name} ${response.data.last_name}`);}
    }).catch((err)=> {
      console.error(err);
    });

    axios.get(`/mostcomments/${this.props.match.params.userId}`)
    .then(response => {
      if(this._isMounted) {
        this.setState({most_comment: response.data});}
    }).catch((err)=> {
      console.error(err);
    });
    
    axios.get(`/mostrecent/${this.props.match.params.userId}`)
    .then(response => {
      if(this._isMounted) {
        this.setState({most_recent: response.data});}
    }).catch((err)=> {
      console.error(err);
    });
  }

  componentDidUpdate = (prevProps) => {
    this._isMounted = true;
    if (this.props.match.params.userId !== prevProps.match.params.userId) {
      axios.get(`/user/${this.props.match.params.userId}`)
      .then(response => {
        if (this._isMounted) {
          this.setState({
            user: response.data,
          });
          this.props.changeTitle(`User Profile: ${response.data.first_name} ${response.data.last_name}`);
        }
      }).catch((err)=> {
        console.error(err);
      });

      axios.get(`/mostcomments/${this.props.match.params.userId}`)
      .then(response => {
        if (this._isMounted) {
          this.setState({
            most_comment: response.data,
          });
        }
      }).catch((err)=> {
        console.error(err);
      });

      axios.get(`/mostrecent/${this.props.match.params.userId}`)
      .then(response => {
        if (this._isMounted) {
          this.setState({
            most_recent: response.data,
          });
        }
      }).catch((err)=> {
        console.error(err);
      });

    }
  };

  componentWillUnmount() {
    this._isMounted = false;
  }

  render() {
    return this.state.user ? (
      <Grid container columnspacing={{ xs: 4, sm: 8, md: 12 }} direction="column" spacing = {8}>
        <Grid item className = "user-info" columnspacing={{ xs: 4, sm: 8, md: 12 }}>
          <Typography className= "user-name" variant="h2">
            {`${this.state.user.first_name} ${this.state.user.last_name}`}
          </Typography>
          <Typography variant="h4">
            {`${this.state.user.location}`}
          </Typography>
          <Typography variant="h5">
            {`${this.state.user.occupation}`}
          </Typography>
          <Typography className = "user-description" variant="body1">{this.state.user.description}</Typography>
        </Grid>

        <Grid item columnspacing={{ xs: 4, sm: 8, md: 12 }}>
          <Button className = "to-photo" variant="contained">
              <Link to={`/photos/${this.state.user._id}`}>View his/her Photos</Link>
          </Button>
        </Grid>
        <Divider />
      
        <Grid item columnspacing={{ xs: 4, sm: 8, md: 12 }}>
        <Typography variant="h5">
                {`Most comments photo`}
        </Typography>
          {this.state.most_comment
          .map((photo)=>{
            return (
              <Box key={photo._id} className="user-detail-most-comments">
                <HashLink to={`/photos/${this.state.user._id}#photo${photo._id}`}>
                  <Card className="user-detail-photo">
                    <CardMedia
                      component="img"
                      image={`/images/${photo.file_name}`} />
                  </Card>
                </HashLink>
                <Typography variant="body2">
                  {`This photo has ${photo.comments.length} comments`}
                </Typography>
              </Box>
            );
          })
          }
        </Grid>
        <Divider />
        <Grid item columnspacing={{ xs: 4, sm: 8, md: 12 }}>
          <Typography variant="h5">
              {`Most recent photo`}
          </Typography>
          <Box className="user-detail-most-comments">
            <HashLink to={`/photos/${this.state.user._id}#photo${this.state.most_recent._id}`}>
              <Card className = "user-detail-photo">
                {this.state.most_recent.file_name?
                (
                <CardMedia
                component="img"
                image={`/images/${this.state.most_recent.file_name}`}/>
                )
                : null
                }
                {/* <CardMedia
                  component="img"
                  image={`/images/${this.state.most_recent.file_name}`}/> */}
              </Card>
            </HashLink>
            <Typography variant="body2">
              {`${this.state.most_recent.date_time}`}
            </Typography>
          </Box>
            
        </Grid>
          <Divider />
          <Grid item columnspacing={{ xs: 4, sm: 8, md: 12 }}>
              <Typography variant="h5">
                  {`Mentioned photos`}
              </Typography>
              {this.state.user.mentioned_photos.length > 0 ? (
                this.state.user.mentioned_photos.map((photoId,index) => {
                  return <MentionPhotoCard key={`photoId_${photoId}${index}`} photoId={photoId}/>;
                })
              ) : (
                <Typography variant="body2">No one has mentioned this user yet...</Typography>
              )}
          </Grid>
      </Grid>
    ) : (
      <div>loading...</div>
    );
  }
}

export default UserDetail;