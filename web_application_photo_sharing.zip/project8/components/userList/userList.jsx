import React from 'react';
import {
  Divider,
  List,
  ListItem,
  ListItemText,
  Typography
}

from '@material-ui/core';
import './userList.css';
import { Link } from "react-router-dom";
import axios from 'axios';


/**
 * Define UserList, a React componment of CS142 project #5
 */
class UserList extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      users: undefined
    };
  
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/user/list`)
    .then((response) => {
      if (this._isMounted) {
        this.setState({users: response.data});
      }
    }).catch((err)=> {
      console.error(err);
    });
  }

  render() {
    return (
      <div>
        <Typography className = "user-list-title" variant="h5">
          USER LIST
        </Typography>
        <List component="nav">
          {this.state.users ? (
            this.state.users.map(user => {
              return (
              <Link to={`/users/${user._id}`} key={user._id}>
              <ListItem className='user-list-item'>
                <ListItemText>
                    {`${user.first_name} ${user.last_name}`}
                </ListItemText>
              </ListItem>
              <Divider />
              </Link>
              );
            })
          ) : (
            <div>Loading...</div>
          )}
        </List>
      </div>
    );
  }
}

export default UserList;
