export default {
    control: {
      backgroundColor: '#FFFFFF',
      fontSize: 18,
      fontWeight: 'normal',
    },
  
    // '&singleLine': {
    //   display: 'inline-block',
    //   width: 400,
  
    //   highlighter: {
    //     padding: 5,
    //     border: '2px inset transparent',
    //   },
    //   input: {
    //     padding: 2,
    //     border: '2px inset',
    //   },
    // },
  
    '&multiLine': {
      control: {
        minHeight: 100,
      },
      highlighter: {
        padding: 9,
        border: '1px solid transparent',
      },
      input: {
        padding: 9,
        border: '1px solid silver',
      },
    },

    suggestions: {
      list: {
        backgroundColor: 'white',
        border: '1px solid rgba(5,5,5,5)',
        fontSize: 16,
      },
      item: {
        padding: '5px 15px',
        borderBottom: '1px solid rgba(0,0,0,0.15)',
        '&focused': {
          backgroundColor: '#F0F8FF',
        },
      },
    },
  }