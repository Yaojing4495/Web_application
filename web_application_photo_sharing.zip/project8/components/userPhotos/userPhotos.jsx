import React from 'react';
import {
  Typography,
  Grid,
  Button,
  Card,
  CardMedia,
  CardContent,
  Divider,
  Box,
  IconButton
} from '@material-ui/core';
import './userPhotos.css';
import { Link } from "react-router-dom";
import axios from 'axios';
import {
  ThumbUp,
  ThumbUpOutlined,
  Favorite,
  FavoriteBorder,
  Send
} from "@material-ui/icons";
import { MentionsInput, Mention } from "react-mentions";
import mention_style from "./mention_style.js";

/**
 * Define UserPhotos, a React componment of CS142 project #5
 */
class UserPhotos extends React.Component {
  _isMounted = false;
  constructor(props) {
    super(props);
    this.state = {
      photos:undefined,
      user:undefined,
      //liked:undefined,
      favorited:[],
      this_user:this.props.this_user,
      //favorite_photos:[],
      comment_mention:[],
      mention_list:[],
      // comment_status:""
      comment:{}
    };
    this.addNewComment = this.addNewComment.bind(this);
    this.handleLike = this.handleLike.bind(this);
  }

  componentDidMount() {
    this._isMounted = true;
    axios.get(`/photosOfUser/${this.props.match.params.userId}`)
    .then(response => {
      // let photo_length = response.data.length;
      // let temp_comment = [];
      // for (let i = 0; i < photo_length; i++) {
      //   temp_comment.push("");
      // }
      if(this._isMounted) {
        //console.log(response.data);
        this.setState({
          photos: response.data});}
    }).catch((err)=> {
      console.error(err);
    });

    axios.get(`/user/${this.props.match.params.userId}`)
    .then(response => {
      if(this._isMounted) {
      this.setState({user: response.data});
      this.props.changeTitle(`Photos of: ${response.data.first_name} ${response.data.last_name}`);}
    }).catch((err)=> {
      console.error(err);
    });

    axios.get(`/getFavoritePhoto`)
      .then(() => {
        if (this._isMounted) {
          console.log("get favorite photo");
        }
      }).catch((err)=> {
        console.error(err);
      });

    axios.get(`/user/list`)
      .then((response) => {
        if (this._isMounted) {
          let comment_mention_list = [];
          for (let i = 0; i<response.data.length; i++) {
            comment_mention_list[i] = {id:response.data[i]._id,display:`${response.data[i].first_name} ${response.data[i].last_name}` };
          }
          this.setState({
            mention_list: comment_mention_list,
          });
        }
      }).catch((err)=> {
        console.error(err);
      });

    axios.get(`/user/${this.props.this_user._id}`)
    .then(response => {
      if(this._isMounted) {
        //console.log("here1")
        //console.log(response.data)
      this.setState({this_user: response.data});
      //console.log(JSON.stringify(this.state))
    }
    }).catch((err)=> {
      console.error(err);
    });
  }
  

  componentDidUpdate = (prevProps, prevState) => {
    this._isMounted = true;
    if (prevState.favorited !== this.state.favorited) {
    // console.log(prevState.favorited)
    // console.log(this.state.favorited)
    // console.log("here0")
    axios.get(`/user/${this.props.this_user._id}`)
    .then(response => {
      if(this._isMounted) {
        //console.log("here1")
        //console.log(response.data)
      this.setState({this_user: response.data});
      //console.log(JSON.stringify(this.state))
    }
    }).catch((err)=> {
      console.error(err);
    });

    }
  };

  handleLike = (photo) => {
    axios.post(`/likePhoto/${photo._id}`, {
       like_photo: !(photo.liked_user.indexOf(this.props.this_user._id) > -1)
      }).then(() => {   
        //this.setState({liked: !(photo.liked_user.indexOf(this.props.this_user._id) > -1)});
        window.location.reload();
      }).catch(err => console.log(err.response));
  };


  addFavorite = (photo,favoriteId) => {
    //console.log(this.state.mention_list);
    //let addFavoriteBtn = document.getElementById(favoriteId);
    console.log(favoriteId);
    //console.log(this.props.this_user.favorite_photos.indexOf(photo._id) > -1);
    axios.post('/addFavoritePhoto', {photo_id: photo._id})
    .then(()=> {
      console.log("added successful");
      let new_favorited = JSON.parse(JSON.stringify(this.state.favorited));
      //console.log(new_favorited);
      new_favorited.push(favoriteId);
      //console.log(new_favorited);
      this.setState({favorited: new_favorited});
    });
  };

  handleChange = (event) => {
    if(event.target.id !== undefined) {
      let new_comment = this.state.comment;
    new_comment[event.target.id] = event.target.value;
    this.setState({comment:new_comment});
    }
  };

  addNewComment=(photoId, userId)=>{
    const promise = axios.post(`/commentsOfPhoto/${photoId}`, 
      {comment: this.state.comment[photoId],
      comment_mention: this.state.comment_mention});
      let new_comment = this.state.comment;
      new_comment[photoId] = "";
    promise.then(() => {
      this.setState({comment_mention:[],comment:new_comment});
        axios.get(`/photosOfUser/${userId}`)
        .then((response)=>{
          this.setState({photos: response.data});
        }).catch((err) => {
          console.error(err);
        });
    }).catch((err)=> {
      console.error(err);
    });
  };

  render() {
    return this.state.user? (
      <Grid container 
      direction="column" 
      alignItems="flex-start">
        <Grid item>
          <Typography variant="h5">
            {`Welcome to ${this.state.user.first_name} ${this.state.user.last_name}'s photo page!`}
          </Typography>
        </Grid>
        
        <Grid item className="user-photo-back">
          <Button variant="outlined" size = "small">
            <Link to={`/users/${this.state.user._id}`} key={this.state.user._id}>
              {`Back to ${this.state.user.first_name} ${this.state.user.last_name}'s homepage`}
            </Link>
          </Button>
        </Grid>

        <Grid item>
          {this.state.photos ? (
            this.state.photos
            .sort((photo_1, photo_2)=> {
              return (photo_2.liked_user.length - photo_1.liked_user.length || new Date(photo_2.date_time) - new Date(photo_1.date_time));
            })
              .map((photo,index) => {
                return (
                <Box key={photo._id} margin = {3} width={600} className='user-photo-box'>
                  <Card id={`photo${photo._id}`}>
                  <CardMedia
                    component="img"
                    image = {`/images/${photo.file_name}`}>
                  </CardMedia>
                  <CardContent>
                    <Grid container direction="row">
                      <Grid item xs={10}>
                          <Typography gutterBottom className="user-photo-time" variant="body2">
                            {`${photo.date_time}`}
                          </Typography>
                      </Grid>
                      <Grid item xs={1}>
                        <IconButton onClick={() => this.handleLike(photo)} color="primary">
                        {photo.liked_user.indexOf(this.props.this_user._id) > -1 ? (
                              <ThumbUp color="primary"/>
                            ) : (
                              <ThumbUpOutlined color="primary"/>
                              )}
                        <Typography variant="body1" color="primary">
                          {photo.liked_user.length}
                        </Typography>
                        </IconButton>
                      </Grid>
                      <Grid item xs={1}>
                        <IconButton color="primary" id={index}
                        disabled={this.state.this_user.favorite_photos.indexOf(photo._id) > -1}
                        onClick={() => this.addFavorite(photo,index)}
                        >
                        {
                        (this.state.this_user.favorite_photos.indexOf(photo._id) > -1) ? (
                            <Favorite color="primary"/>
                          ) : (
                            <FavoriteBorder color="primary"/>
                            )
                        }
                        </IconButton>
                      </Grid>
                    </Grid>
                    <Typography className="user-photo-comment-title" variant="body1">Comments:</Typography>
                    {photo.comments ? photo.comments.map(comment => 
                      {return (
                        <Box key={comment._id} margin={2} className='user-photo-comment-box'>
                          <Divider />
                          <Grid className="user-photo-comment-creater">
                            {`${comment.date_time} from : `}
                            <Link to={`/users/${comment.user._id}`}>
                                {`${comment.user.first_name} ${comment.user.last_name}`}
                            </Link>
                          </Grid>
                          <Grid item className="user-photo-comment-content">
                          {comment.comment.replace(
                            /@\[(\S+ \S+)( )*\]\(\S+\)/g,
                            (match, display_name) => {
                            return `@[${display_name}]`;
                          }
                        )}
                          </Grid>
                        </Box>
                    );}
                    ) : (
                      <Box margin={3}>
                        No comments yet...
                      </Box>
                    )}
                    {/* <form onSubmit = {() => this.addNewComment(photo._id,photo.user_id)}>
                        {'Add a comment:  '}
                        <input type = "text" id={`${photo._id}`}></input>
                        <Button type="submit" color="primary">send</Button>
                    </form> */}
                    <form onSubmit = {() => this.addNewComment(photo._id,photo.user_id)}>
                      <Grid container direction="row" justifycontent="space-around" alignitems="center">
                        <Grid item xs={11}> 
                        <MentionsInput id={`${photo._id}`}
                          className='user-photo-input-comment'
                          value={this.state.comment[photo._id]}
                          onChange={this.handleChange}
                          multiline="true"
                          style={mention_style}
                        >
                          <Mention
                            trigger="@"
                            data={this.state.mention_list}
                            displayTransform={(id, display) => `@${display}`}
                            onAdd={(id) => {
                              let mentioned_users = this.state.comment_mention;
                              mentioned_users.push(id);
                              this.setState({comment_mention: mentioned_users});
                            }}
                          />
                        </MentionsInput>
                        </Grid>
                        <Grid item xs={1} alignitems="center">
                        {/* <ThumbUp type="submit" color="primary"/> */}
                        {/* <Button type="submit" color="primary">send</Button> */}
                        <IconButton color="primary" 
                        type="submit"
                        >
                        <Send type="submit" color="primary"/>
                        </IconButton>
                        </Grid>
                      </Grid>
                    </form>  
                  </CardContent>
                  </Card>
                  
                </Box>
                
                );
              })
            ) : (
              <div>No photos yet...</div>
            )}
        </Grid>      


      </Grid>
    ) : (
    <div>loading...</div>
    );
  }
}

export default UserPhotos;
