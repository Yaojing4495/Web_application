import React from 'react';
import ReactDOM from 'react-dom';
import {
  HashRouter, Route, Switch,Redirect
} from 'react-router-dom';
import {
  Grid, Typography, Paper
} from '@material-ui/core';
import './styles/main.css';

// import necessary components
import TopBar from './components/topBar/TopBar';
import UserDetail from './components/userDetail/userDetail';
import UserList from './components/userList/userList';
import UserPhotos from './components/userPhotos/userPhotos';
//import UserPhotosNew from './components/UserPhotosNew/UserPhotosNew';
import LoginRegister from './components/LoginRegister/LoginRegister';
import Favorites from "./components/Favorites/Favorites";

class PhotoShare extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      title: "Home Page",
      feature: false,
      this_user: JSON.parse(localStorage.getItem('user'))
    };
    this.changeTitle = this.changeTitle.bind(this);
    this.changeFeature = this.changeFeature.bind(this);
    this.changeLogin = this.changeLogin.bind(this);
  }

  changeTitle = (newtitle) => {
      this.setState({title: newtitle});
    };

  changeFeature = (newfeature) => {
    this.setState({feature: newfeature});
  };

  changeLogin = (user) => {
    this.setState({this_user: user});
    sessionStorage.setItem('user',JSON.stringify(user));
  };

  render() {
    return (
      <HashRouter>
      <div>
      <Grid container spacing={8}>
        <Grid item xs={12}>
          <TopBar title={this.state.title} feature={this.state.feature} 
          this_user = {this.state.this_user} changeFeature={this.changeFeature}
          changeLogin={this.changeLogin}/>
        </Grid>
        <div className="cs142-main-topbar-buffer"/>
        <Grid item sm={3}>
          <Paper className="cs142-main-grid-item">
            {this.state.this_user ? <UserList /> : null}
          </Paper>
        </Grid>
        <Grid item sm={9}>
          <Paper className="cs142-main-grid-item">
            <Switch>

              <Route path="/login-register" 
                render={props => <LoginRegister {...props} changeLogin={this.changeLogin}/>}  
              />

              {
                this.state.this_user ? 
                (
                  <Route exact path="/"
                    render={() => (
                    <Typography variant="body1">
                      Welcome to your photosharing app! 
                    </Typography>
                    )}
                  />
                ) :
                <Redirect path="/" to="/login-register" />
              }

              {
                this.state.this_user ? (
                  <Route
                    path="/favorites"
                    render={props => <Favorites {...props} />}
                  />
                ) : (
                  <Redirect path="/favorites" to="/login-register" />
                )
              }

              {
                this.state.this_user? 
                (
                  <Route path="/users/:userId"
                  render={ props => <UserDetail feature={this.state.feature} changeTitle={this.changeTitle} changeFeature = {this.changeFeature} {...props}/> }
                />
                ) :
                <Redirect path="/users/:userId" to="/login-register" />
              }
              {
                this.state.this_user? 
                (
                    <Route path="/photos/:userId"
                      render ={ props => <UserPhotos this_user={this.state.this_user} feature={this.state.feature} changeTitle={this.changeTitle} changeFeature = {this.changeFeature} {...props}/> }
                    />
                ) :
                <Redirect path="/photos/:userId" to="/login-register" />
              }

            </Switch>
          </Paper>
        </Grid>
      </Grid>
      </div>
      </HashRouter>
    );
  }
}


ReactDOM.render(
  <PhotoShare />,
  document.getElementById('photoshareapp'),
);