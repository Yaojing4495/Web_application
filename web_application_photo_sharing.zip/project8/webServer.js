/* jshint node: true */

/*
 * This builds on the webServer of previous projects in that it exports the current
 * directory via webserver listing on a hard code (see portno below) port. It also
 * establishes a connection to the MongoDB named 'cs142project6'.
 *
 * To start the webserver run the command:
 *    node webServer.js
 *
 * Note that anyone able to connect to localhost:portNo will be able to fetch any file accessible
 * to the current user in the current directory or any of its children.
 *
 * This webServer exports the following URLs:
 * /              -  Returns a text status message.  Good for testing web server running.
 * /test          - (Same as /test/info)
 * /test/info     -  Returns the SchemaInfo object from the database (JSON format).  Good
 *                   for testing database connectivity.
 * /test/counts   -  Returns the population counts of the cs142 collections in the database.
 *                   Format is a JSON object with properties being the collection name and
 *                   the values being the counts.
 *
 * The following URLs need to be changed to fetch there reply values from the database.
 * /user/list     -  Returns an array containing all the User objects from the database.
 *                   (JSON format)
 * /user/:id      -  Returns the User object with the _id of id. (JSON format).
 * /photosOfUser/:id' - Returns an array with all the photos of the User (id). Each photo
 *                      should have all the Comments on the Photo (JSON format)
 *
 */

var mongoose = require('mongoose');
mongoose.Promise = require('bluebird');

var async = require('async');
var express = require('express');
var app = express();
const fs = require("fs");
const session = require('express-session');
const bodyParser = require('body-parser');
const multer = require('multer');
// Load the Mongoose schema for User, Photo, and SchemaInfo
var User = require('./schema/user.js');
var Photo = require('./schema/photo.js');
var SchemaInfo = require('./schema/schemaInfo.js');
const processFormBody = multer({storage: multer.memoryStorage()}).single('uploadedphoto');


// XXX - Your submission should work without this line. Comment out or delete this line for tests and before submission!
// var cs142models = require('./modelData/photoApp.js').cs142models;

mongoose.connect('mongodb://localhost/cs142project6', { useNewUrlParser: true, useUnifiedTopology: true });

// We have the express static module (http://expressjs.com/en/starter/static-files.html) do all
// the work for us.
app.use(express.static(__dirname));

app.use(session({secret: 'secretKey', resave: false, saveUninitialized: false}));
app.use(bodyParser.json());

app.get('/', function (request, response) {
    response.send('Simple web server of files from ' + __dirname);
});

/*
 * Use express to handle argument passing in the URL.  This .get will cause express
 * To accept URLs with /test/<something> and return the something in request.params.p1
 * If implement the get as follows:
 * /test or /test/info - Return the SchemaInfo object of the database in JSON format. This
 *                       is good for testing connectivity with  MongoDB.
 * /test/counts - Return an object with the counts of the different collections in JSON format
 */
app.get('/test/:p1', function (request, response) {
    // Express parses the ":p1" from the URL and returns it in the request.params objects.
    console.log('/test called with param1 = ', request.params.p1);

    var param = request.params.p1 || 'info';

    if (param === 'info') {
        // Fetch the SchemaInfo. There should only one of them. The query of {} will match it.
        SchemaInfo.find({}, function (err, info) {
            if (err) {
                // Query returned an error.  We pass it back to the browser with an Internal Service
                // Error (500) error code.
                console.error('Doing /user/info error:', err);
                response.status(500).send(JSON.stringify(err));
                return;
            }
            if (info.length === 0) {
                // Query didn't return an error but didn't find the SchemaInfo object - This
                // is also an internal error return.
                response.status(500).send('Missing SchemaInfo');
                return;
            }

            // We got the object - return it in JSON format.
            console.log('SchemaInfo', info[0]);
            response.end(JSON.stringify(info[0]));
        });
    } else if (param === 'counts') {
        // In order to return the counts of all the collections we need to do an async
        // call to each collections. That is tricky to do so we use the async package
        // do the work.  We put the collections into array and use async.each to
        // do each .count() query.
        var collections = [
            {name: 'user', collection: User},
            {name: 'photo', collection: Photo},
            {name: 'schemaInfo', collection: SchemaInfo}
        ];
        async.each(collections, function (col, done_callback) {
            col.collection.countDocuments({}, function (err, count) {
                col.count = count;
                done_callback(err);
            });
        }, function (err) {
            if (err) {
                response.status(500).send(JSON.stringify(err));
            } else {
                var obj = {};
                for (var i = 0; i < collections.length; i++) {
                    obj[collections[i].name] = collections[i].count;
                }
                response.end(JSON.stringify(obj));

            }
        });
    } else {
        // If we know understand the parameter we return a (Bad Parameter) (400) status.
        response.status(400).send('Bad param ' + param);
    }
});

/*
 * URL /user/list - Return all the User object.
 */
app.get('/user/list', function (request, response) {
    let session_userId = request.session.user_id;
    if (session_userId !== undefined && session_userId !== null) {
        User.find({}, (err, data) => {
            console.log(data);
            if (err || data === null) {
                console.log("cannot get user list");
                response.status(500).send(err);
                return;
            }
    
            let userList = [];
            async.each(data, function(user, done_callback) {
                let this_user = {
                    _id: user._id,
                    first_name: user.first_name,
                    last_name: user.last_name
                };
                userList.push(this_user);
                done_callback();
            }, (error) => {
                if (error) {
                    console.log(error);
                    response.status(500).send(error);
                } 
            });
            console.log("all done");
            response.status(200).send(JSON.stringify(userList));
        });
    } else {
        response.status(401).send("Unauthorized");
    }
});

/*
 * URL /user/:id - Return the information for User (id)
 */
app.get('/user/:id', function (request, response) {
    let session_userId = request.session.user_id;
    if (session_userId !== undefined && session_userId !== null) {
        let id = request.params.id;
        User.findOne({_id: id}, (err, data) => {
            if (err || data === null) {
                console.log('User with _id:' + id + ' not found.');
                response.status(400).send(err);
                return;
            }
            let user = {
                _id: data._id,
                first_name: data.first_name,
                last_name: data.last_name,
                location: data.location,
                description: data.description,
                occupation: data.occupation,
                favorite_photos: data.favorite_photos,
                mentioned_photos: data.mentioned_photos
            };
            response.status(200).send(JSON.stringify(user));
        });
    } else {
        response.status(401).send("Unauthorized");
    }
});

/*
 * URL /photosOfUser/:id - Return the Photos for User (id)
 */
app.get('/photosOfUser/:id', function (request, response) {
    let session_userId = request.session.user_id;
    if (session_userId !== undefined && session_userId !== null) {
        let id = request.params.id;
        Photo.find({user_id: id}, function(err, data) {
            if (err || data === null) {
                console.log('Photos with _id:' + id + ' not found.');
                response.status(400).send(err);
                return;
            }
            let photos_list = [];
            for (let i = 0; i < data.length; i++) {
                let comments_list= [];
                let photo = {
                    _id: data[i]._id,
                    user_id: data[i].user_id,
                    comments: comments_list,
                    file_name: data[i].file_name,
                    date_time: data[i].date_time,
                    liked_user: data[i].liked_user,
                    favorite_photos:data[i].favorite_photos
                };
                for (let j = 0; j < data[i].comments.length; j++) {
                    let comment = {
                        comment: data[i].comments[j].comment,
                        date_time: data[i].comments[j].date_time,
                        _id: data[i].comments[j]._id,
                        user: {_id: data[i].comments[j].user_id}
                    };
                    comments_list.push(comment);
                }
                photos_list.push(photo);
            }
            async.each(photos_list, (photo,done_callback) => {
                async.each(photo.comments, function(comment, done_callback2) {
                    User.findOne({_id: comment.user._id}, function(err1, comment_user) {
                        if (err1) {
                            console.log('cannot get comment user info');
                            response.status(400).send(err1);
                            return;
                        }
                        let comment_user_info = {
                            _id: comment_user._id,
                            first_name: comment_user.first_name,
                            last_name: comment_user.last_name
                        };
                        comment.user = comment_user_info;
                        done_callback2();
                    });
                }, (err2) => {
                    done_callback(err2);
                });
            },  (err3) => {
                if (err3) {
                    response.status(500).send(err3);
                } else {
                    response.status(200).send(JSON.stringify(photos_list));
                }
            });
        });
    } else {
        response.status(401).send("Unauthorized");
    }
});

// login
app.post('/admin/login', function(request, response) {
    let processed_password = request.body.password;
    User.findOne({login_name: request.body.login_name}, (err, user) => {
      if (err) {
        console.log(request.body.login_name + " not found");
        response.status(401).send("error finding");
        return;
      }
      if (user === undefined || user === null) {
        console.log(request.body.login_name + " not found");
        response.status(400).send("this user does not exist");
        return;
      }
      if (user.password !== processed_password) {
        response.status(400).send("wrong password");
        return;
      }
      let thisUser = {
        _id: user._id,
        first_name: user.first_name,
        last_name: user.last_name,
        login_name: user.login_name,
        favorite_photos: user.favorite_photos
    };
      request.session.user_id = user._id;
      request.session.login_name = request.body.login_name;
      response.status(200).send(thisUser);
    });
  });

// logout
app.post("/admin/logout", function(request, response) {
    //request.session is an object you can read or write
    request.session.destroy(function(err) {
      if (err) {
        response.status(400).send();
        return;
      }
      response.status(200).send();
    });
  });

// register
app.post("/user", function(request, response) {
    User.findOne({
        login_name: request.body.login_name
    }, function(err, user) {
        if (err) {
            response.status(400).send("verifying error");
            return;
        }
        if (user) {
            response.status(400).send("Username already exists, please use another username");
            return;
        }
        let new_register = {
            login_name:request.body.login_name, 
            password:request.body.password,  
            first_name:request.body.first_name, 
            last_name:request.body.last_name, 
            location:request.body.location, 
            description:request.body.description, 
            occupation:request.body.occupation,
            favorite_photos: request.body.favorite_photos
        };
        User.create(new_register, function(error, new_user) {
            if (error) {
              response.status(400).send('failed to register');
              return;
            }
            request.session.user_id = new_user._id;
            request.session.login_name = request.body.login_name;

            new_register._id = new_user._id;
            response.status(200).send(new_register);
          });
    });
  
  });

// upload photos
app.post('/photos/new', function(request, response) {
    let session_userId = request.session.user_id;
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    processFormBody(request, response, function(err) {
        if (err || request.file === null) {
            response.status(400).send("failed to upload file");
            return;
        }
        const timestamp = new Date().valueOf();
        const filename = 'U' +  String(timestamp) + request.file.originalname;

        fs.writeFile("./images/" + filename, request.file.buffer, function (error1) {
            if (error1) {
                response.status(400).send(error1);
                return;
            }
            let new_photo = {
                file_name: filename,
                date_time: timestamp,
                user_id: session_userId,
                comments: []
            };
            Photo.create(new_photo, function(errors) {
                if (errors) {
                    response.status(400).send("failed to create new photo");
                    return;
                }
                response.status(200).send(new_photo);
            });
          });
    });

});

// get info of a photo
app.get("/singlePhoto/:photo_id", function(request, response) {
    let session_userId = request.session.user_id;
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    Photo.findOne({_id: request.params.photo_id}, function(error, photo) {
      if (error) {
        response.status(400).send("cannot find this photo");
        return;
      }
      User.findOne({_id: photo.user_id}, function(err, creater) {
        if (err) {
            response.status(400).send("cannot find this user");
            return;
        }
        let this_photo = {
          _id: request.params.photo_id,
          photo_creater_id: creater._id,
          file_name: photo.file_name,
          creater_first_name: creater.first_name,
          creater_last_name: creater.last_name
        };
        response.status(200).send(this_photo);
        //return;
      });
    });
  });

// like a photo
app.post(`/likePhoto/:photo_id`, function(request, response) {
    let session_userId = request.session.user_id;
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    Photo.findOne({ _id: request.params.photo_id}, function(error, this_photo) {
      if (error) {
        response.status(400).send("cannot find this photo id");
        return;
      }
      if (request.body.like_photo) {
        this_photo.liked_user.push(session_userId);
      } else {
        let index = this_photo.liked_user.indexOf(session_userId);
        this_photo.liked_user.splice(index, 1);
      }
      this_photo.save();
      response.status(200).send();
    });
  });

// add a photo to favorite list
app.post(`/addFavoritePhoto`, function(request, response) {
    let session_userId = request.session.user_id;
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    User.findOne({ _id: session_userId}, function(error, user) {
      if (error || user === undefined || !user) {
        response.status(400).send('cannot find this user id');
        return;
      }
      if (user.favorite_photos.includes(request.body.photo_id)) {
        response.status(200).send();
      } else {
        user.favorite_photos.push(request.body.photo_id);
        user.save();
        response.status(200).send();
      }
    });
  });

// delete a photo from favorite list
app.get("/deleteFavoritePhoto/:photo_id", function(request, response) {
    let session_userId = request.session.user_id;
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    User.findOne({_id: session_userId}, function(error, user) {
      if (error || user === undefined || !user) {
        response.status(400).send("cannot find this user id");
        return;
      } else {
        const photo_index = user.favorite_photos.indexOf(request.params.photo_id);
        user.favorite_photos.splice(photo_index, 1);
        user.save();
      }
      response.status(200).send();
    });
  });

// get all the favorite photo
app.get(`/getFavoritePhoto`, function(request, response) {
    let session_userId = request.session.user_id;
    let favoritesList = [];
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    User.findOne({_id: session_userId}, function(error, user) {
        if (error || user === undefined || !user) {
            response.status(400).send("cannot find this user id");
            return;
        }
        function addFavoritePhoto(photo_id, Callback) {
            Photo.findOne({_id: photo_id}, function(error1, photo) {
                if (error1) {
                    response.status(400).send("cannot find this photo id");
                    return;
                }
                favoritesList.push({
                    _id: photo._id,
                    file_name: photo.file_name,
                    date_time: photo.date_time,
                    user_id: photo.user_id
                }); Callback();
            });
        }
        function DoneCallBack(err) {
            if (err) {
                response.status(400).send(err);
                return;
            }
            response.status(200).send(favoritesList);
        }
        async.each(user.favorite_photos, addFavoritePhoto, DoneCallBack);
    });
});

// get the most comments photo
app.get('/mostcomments/:id', function (request, response) {
    let session_userId = request.session.user_id;
    if (session_userId !== undefined && session_userId !== null) {
        let id = request.params.id;
        Photo.find({user_id: id}, (err, data) => {
            if (err || data === null || data === undefined) {
                console.log("not found");
                response.status(400).send(err);
                return;
            }
            let mostCommentsList = [];

            let tempMostCommentsPhoto = data[0];
            for (let i = 0; i < data.length; i++) {
              if (data[i].comments.length >= tempMostCommentsPhoto.comments.length) {
                tempMostCommentsPhoto = data[i];
              } 
            }

            let NumOfComments = tempMostCommentsPhoto.comments.length;
            for (let i = 0; i < data.length; i++) {
                if (data[i].comments.length === NumOfComments) {
                    let OneOfMostComment = {
                        _id: data[i]._id,
                        file_name: data[i].file_name,
                        comments: data[i].comments,
                        date_time: data[i].date_time
                    };
                    mostCommentsList.push(OneOfMostComment);
                } 
              }

            response.status(200).send(JSON.stringify(mostCommentsList));
        });
    } else {
        response.status(401).send("Unauthorized");
    }
});

// get the most recent photo
app.get('/mostrecent/:id', function (request, response) {
    let session_userId = request.session.user_id;
    if (session_userId !== undefined && session_userId !== null) {
        let id = request.params.id;
        Photo.find({user_id: id}, (err, data) => {
            if (err || data === null || data === undefined) {
                console.log("not found");
                response.status(400).send(err);
                return;
            }
            let tempMostRecent = data[0];
            for (let i = 0; i < data.length; i++) {
              if (data[i].date_time > tempMostRecent.date_time) {
                tempMostRecent = data[i];
              }
            }
            let mostrecent = {
                _id: tempMostRecent._id,
                file_name: tempMostRecent.file_name,
                comments: tempMostRecent.comments,
                date_time: tempMostRecent.date_time
            };
            response.status(200).send(JSON.stringify(mostrecent));
        });
    } else {
        response.status(401).send("Unauthorized");
    }
});

// post comments with @mentions
app.post('/commentsOfPhoto/:photo_id', function(request, response) {
    let session_userId = request.session.user_id;
    if (session_userId === undefined || session_userId === null) {
        response.status(401).send("Unauthorized");
        return;
    } 
    if (request.body.comment === undefined || request.body.comment === null || request.body.comment==="") {
        response.status(400).send("invalid comments");
        //return;
    } else {
        Photo.findOne({_id: request.params.photo_id}, function(err, this_photo) {
            if (err) {
                response.status(400).send(err);
                return;
            }
            if (this_photo === undefined || this_photo === null) {
                response.status(400).send("photo not found");
                return;
            }
            let now = new Date();
            let new_comment = {
                comment: request.body.comment,
                user_id: session_userId,
                date_time: now.toISOString()
            };
            this_photo.comments = this_photo.comments.concat([new_comment]);
            this_photo.save();

            function DoneCallBack(err1) {
                if (err1) {
                    response.status(400).send(err1);
                    return;
                }
                response.status(200).send();
            }
            function createMention(session_userid, Callback) {
                User.findOne({_id: session_userid}, function(error1, this_user) {
                    if (error1) {
                        response.status(400).send("cannot find this user");
                        //return;
                    } else {
                        this_user.mentioned_photos.push(request.params.photo_id);
                        this_user.save();
                        Callback();
                    }
                });
            }
            async.each(request.body.comment_mention, createMention, DoneCallBack);

        });
    }

});

var server = app.listen(3000, function () {
    var port = server.address().port;
    console.log('Listening at http://localhost:' + port + ' exporting the directory ' + __dirname);
});


